# AGENTS.md — Konteks proyek POS Terintegrasi

Dokumen serah-terima untuk agen/AI coding yang melanjutkan proyek ini. Baca SELURUHNYA sebelum mengubah apa pun.
Terakhir diperbarui: 22 Okt 2026.

## 1. Tentang proyek
Aplikasi POS web terintegrasi (multi-cabang + pusat) untuk toko buku/rohani. Database Supabase (Postgres) terpusat.
- Pemilik proyek berbahasa Indonesia dan bukan programmer berpengalaman. **Jelaskan pelan-pelan, sederhana, langkah demi langkah** (klik apa, ketik apa). Balas dalam bahasa Indonesia.
- Dikembangkan di PC desktop (Windows/Linux/macOS). Version control lewat repo GitHub → **jangan pernah commit data sensitif**.
- Ada template tampilan referensi (prototipe React-CDN dengan tema hijau); tampilannya sudah dipindahkan ke proyek ini. Template TIDAK dipakai untuk logika (ia hanya menyimpan data di memori browser dan mengecek hak akses di sisi klien, jadi tidak aman).

## 2. Stack
Vite 5 + React 18 + TypeScript (strict) + Tailwind v4 (dark mode lewat class `dark`, warna `brand-*` hijau) + React Router 6 + TanStack Query 5 + lucide-react + `@supabase/supabase-js`. Tanpa server sendiri: browser bicara langsung ke Supabase; aturan penting dijaga di database (RLS + fungsi RPC `security definer`).
Skrip impor: Node + `exceljs`. Tes SQL: `@electric-sql/pglite`.

## 3. Struktur folder
```
supabase/schema.sql                         tabel, RLS, RPC awal, seed role/fitur
supabase/migrations/002_products_import.sql kolom author, attributes[], constraint harga aktif > 0
supabase/migrations/003_costs_and_line_discount.sql  harga beli rahasia + diskon per baris + create_sale baru
supabase/migrations/004_stock_views.sql     stock_by_branch, set_stock, adjust_stock (cek cabang)
supabase/migrations/005_user_permissions.sql hak granular: user_permissions, has_perm baru, RPC kelola role/user
supabase/migrations/006_email_domain.sql    trigger: akun BARU wajib @takom.id
supabase/migrations/007_revoke_sessions.sql revoke_user_sessions (hanya service_role)
supabase/migrations/008_active_branch.sql   my_scope() + create_sale(p_branch): cabang aktif untuk role lintas cabang
supabase/migrations/009_stock_tools.sql     import_stock() (impor CSV dari aplikasi), transfer_stock() (mutasi antar cabang), alasan transfer_in/out
supabase/migrations/010_print_templates.sql  tabel print_templates (baca: semua user; tulis: hanya RPC save_print_template, superadmin)
src/features/print/                         templates.ts (bawaan = nota lama TAKOM, merge aman, token), views.tsx (ReceiptView 80mm, InvoiceView A4, PrintSheet), FormatNotaPage.tsx (editor admin /format-nota)
supabase/migrations/011_sales_recap.sql     RPC sales_recap (bulan/tahun WIB, cabang, halaman 20) + sale_detail (untuk detail & cetak ulang)
src/features/sales/                         SalesRecapPage (filter bulan/tahun/cabang, kartu ringkasan, tabel 20 baris/halaman), SaleDetailModal (detail, cetak struk/A4, void), api.ts
supabase/checks/integritas_stok.sql         pemeriksaan keutuhan (baca saja): stok = riwayat, tanpa minus, total transaksi cocok
supabase/functions/reset-password/index.ts  Edge Function: HANYA superadmin mereset kata sandi user mana pun
supabase/functions/create-user/index.ts     Edge Function pembuat akun login+profil (service_role di sisi Supabase)
scripts/import-products.mjs                 impor Excel master → products (+ product_costs)
scripts/import-stock.mjs                    impor stok awal per cabang dari file hitung fisik (kode, jumlah)
tests/sql-smoke.mjs                         tes SQL otomatis (npm run test:sql)
tests/e2e-flow.mjs                          uji alur lengkap 7 cabang: impor stok, semua metode bayar, diskon per baris, void, mutasi, keutuhan (npm run test:e2e [produk.json])
tests/print-render.mjs                      uji tampilan struk/nota A4 + merge konfigurasi (npm run test:print)
tests/stock-csv.mjs                         uji pembaca CSV stok (npm run test:csv)
src/main.tsx, App.tsx, index.css            provider, route, gaya (.btn/.btn-primary/.btn-ghost/.input = rounded)
src/lib/supabase.ts                         klien (hanya anon key dari .env)
src/shared/                                 format.ts (rupiah), hooks.ts (useDebounced, useIdle), search.ts (cleanSearch), Modal.tsx
src/features/<fitur>/                       modular: halaman + api.ts + komponen per fitur
  auth/      AuthProvider (sesi, profil, can(feature, 'c'|'r'|'u'|'d'), auto-logout 15 menit), guards, LoginPage (ingat email, ikon mata)
  layout/    Layout (sidebar menurut hak akses, header, toggle tema)
  pos/       PosPage (kasir), api.ts, Receipt.tsx (struk 80mm via window.print), types.ts
  products/  ProductsPage (daftar baris + double-click = detail card), ProductForm, ProductDetail, api.ts
  stock/     StockPage, StockEdit, StockByBranch (chip stok per cabang), api.ts
  users/     UsersPage (tab Pengguna & Role), PermMatrix, NewUserModal, api.ts
  settings/  SettingsPage, theme.tsx
```
Fitur baru = folder baru di `features/` + 1 baris di tabel `features` (SQL) + 1 route di `App.tsx` + 1 item NAV di `Layout.tsx`.

## 4. Keputusan bisnis (sudah final, jangan diubah tanpa tanya)
- **Harga produk sama di semua cabang** (satu harga global). Yang berbeda per cabang hanya **stok**.
- **Diskon hanya pilihan tetap 0/5/10/15/20/25%**, TANPA diskon custom dan TANPA approval (promo bulanan = otomatis sah). Diskon **per produk di keranjang**, plus kotak centang "Diskon semua produk". Member/nomor member **wajib** bila ada diskon.
- **Daftar produk berbentuk BARIS** (tabel), bukan card. Kasir: Kode produk | Nama produk | Harga. Halaman Produk menambah kolom Pengarang.
- Double-click baris produk → card per kolom Excel lainnya (urutan sesuai Excel; kolom kosong tidak ditampilkan).
- Alur kasir: pilih produk → klik **Pembayaran (F8)** → pilih diskon (per produk / semua) + member → **Lanjut ke metode bayar** → Tunai (hitung kembalian, tombol uang pas) atau QRIS/Debit/Kartu Kredit (langsung cetak struk).
- Semua tombol/input **rounded**. Mode gelap/terang dengan toggle (header + halaman Pengaturan). Navigasi keyboard: F2 cari, ↑↓ pilih, Enter tambah/buka, F8 maju, Esc mundur, angka 1–4 pilih metode bayar.
- **Stok** (arti kolom Excel menurut pemilik):
  - `stokOnHand` (Excel) = TOTAL akumulasi stok sebuah produk secara global (pusat + semua cabang), BUKAN angka per cabang. Di aplikasi stok disimpan per (cabang, produk) di tabel `stock`; total global = jumlah semua cabang (dihitung, tidak disimpan). Rincian stok sebuah cabang hanya bisa dilihat/diubah user cabang itu dan role lintas cabang.
  - Stok awal (SUDAH DIBUAT): tiap lokasi menghitung stok fisik → file CSV dua kolom `kode`,`jumlah` (template `template_stok_cabang.csv`; Excel Indonesia menyimpan CSV dengan titik koma, sudah ditangani) → halaman **Stok & Pengadaan → Impor stok (CSV)** (RPC `import_stock`, mode "isi stok awal saja" = aman, atau "timpa dengan hasil hitung" = opname). Alternatif baris perintah: `scripts/import-stock.mjs` (butuh kunci service_role lokal). Total Excel `stokOnHand` hanya PEMBANDING (jumlah semua cabang vs 17.337 pcs / 1.285 produk); `StockByBranch` menampilkan "Total semua cabang". Cabang yang stoknya belum diisi = 0 → kasirnya belum bisa menjual (hitung fisik wajib sebelum go-live).
  - **Mutasi stok** antar cabang (SUDAH DIBUAT, migrasi 009): tombol "Pindah stok antar cabang" di halaman Stok; RPC `transfer_stock` atomik, mengunci baris berurutan (anti-deadlock), butuh hak `stock.u` dan akses ke kedua cabang (jadi role lintas cabang), total global tidak berubah.
  - `stokGudLain` = stok yang tampil di SEMUA toko, dikelompokkan per baris/cabang dengan jumlah aktual masing-masing → diwujudkan lewat RPC `stock_by_branch` (nama cabang + jumlah saja, terlihat semua user yang berhak).
  - `stokKonsinyasi` = DIBUANG (belum dipakai). `stokPE` = semua nol, dibiarkan sebagai card.
  - Stok awal diatur user **pengadaan**.
- **Harga beli** (Excel `Price1`; juga `OldPrice1`, `lastCost`) = rahasia, hanya role dengan hak `cost_prices` (superadmin, pengadaan, keuangan). Disimpan di tabel terpisah `product_costs`. **Harga jual = Excel kolom O (`Price2`).**

## 4b. Palet warna (keputusan pemilik)
Palet bertema amber hangat (hue 63), didefinisikan sebagai variabel CSS di `src/index.css` (`:root` = terang, `.dark` = gelap) dan dipetakan ke utilitas Tailwind lewat `@theme inline`: `bg-bg-dark | bg-bg | bg-bg-light`, `text-text | text-text-muted`, `bg-highlight`, `border-border | border-border-muted`, `bg-primary | text-on-primary`, `secondary`, `danger`, `warning`, `success`, `info`. Mode gelap = palet dari pemilik apa adanya; mode terang = turunan (terang-gelap dibalik, hue/chroma sama) dan bisa disetel. `--on-primary` adalah tambahan (teks di atas primary). **Jangan memakai kelas warna Tailwind mentah (slate/amber/red/...) maupun varian `dark:` untuk warna**: pakai token semantik di atas. `bg-bg-light` = panel/kartu (menonjol), `bg-bg-dark` = area tenggelam (header tabel, input), baris terpilih = `bg-primary/20`, hover = `bg-highlight/25`.

## 4c. Cabang & akun (dari pemilik)
Tujuh lokasi (kode `branches.code` yang disarankan): `KRANGGAN` Takom Kranggan · `KATEDRAL` Takom Katedral · `PAULUS` Takom Paulus · `SANTAMARIA` Takom Santa Maria · `ATHANASIUS` Takom Athanasius · `ANTONIUS` Takom Antonius (pemilik menulis "Antoius", diasumsikan salah ketik; KONFIRMASI) · `PUSAT` Takom Pusat (`is_pusat=true`, baris yang sudah ada diganti namanya).
Akun kasir: 1 per cabang, KECUALI Katedral = 2. Role cabang hanya `kasir` (hanya cabangnya sendiri). Takom Pusat: banyak user dengan berbagai role (kabag, pengadaan, keuangan, dst.; lintas cabang), ditambahkan kemudian. Gunakan akun per orang (bukan akun bersama) agar audit jelas; dua kasir Katedral berbagi stok cabang yang sama (aman: pengurangan stok dikunci per baris). Username `<nama>@takom.id`.
Hosting: paket gratis Supabase (500 MB DB, tanpa backup otomatis, proyek dijeda setelah 1 minggu tanpa aktivitas, tanpa SLA). Pro (±$25/bln) = backup harian 7 hari, 8 GB, tanpa jeda. Rekomendasi: backup mandiri terjadwal selama masih gratis dan naik ke Pro sebelum go-live 7 cabang. Pantau ukuran DB: `select pg_size_pretty(pg_database_size(current_database()));`.

**Superadmin (dan role `all_branches`) harus bisa masuk ke SEMUA cabang** (keputusan pemilik, seperti admin pada umumnya): `roles.all_branches=true` membuka data semua cabang (RLS `can_see_branch`), dan header memiliki pemilih **Cabang aktif** (`AuthProvider.activeBranchId`, disimpan di sessionStorage). Di kasir, penjualan atas nama cabang aktif dikirim sebagai `p_branch` ke `create_sale`; server menolaknya untuk role non-lintas-cabang (mis. kasir). Berganti cabang mengosongkan keranjang; header menampilkan peringatan "Bertindak sebagai cabang lain". Halaman rekap/laporan nanti WAJIB memakai `activeBranchId` (atau pilihan "semua cabang").

## 5. Peran & hak akses (RBAC berbasis permission, bukan nama role)
Tabel: `roles`, `features`, `role_permissions(role_id, feature_key, can_create/read/update/delete)`, `profiles(id, full_name, branch_id, role_id, is_active)`. Role = paket permission (template). Granular: tiap USER bisa punya pengecualian per fitur di `user_permissions` (NULL = ikut role, true/false = menimpa); `has_perm()` memakai pengecualian dulu, baru role. Superadmin mengatur semuanya di halaman Pengguna & Hak Akses (matriks Tambah/Lihat/Ubah/Hapus per fitur). Fitur baru = baris baru di tabel `features` → otomatis muncul di matriks. `roles.all_branches=true` → boleh lihat semua cabang.
Role bawaan: `superadmin` (semua, lintas cabang), `kasir` (pos c/r, sales_recap r; hanya cabangnya), `kabag` (sales_recap r, sales_void r/u; lintas cabang), `pengadaan` (products, stock, purchasing c/r/u; cost_prices c/r/u; lintas cabang), `keuangan` (sales_recap r, finance r, cost_prices r; lintas cabang).
Fitur (`features.key`): pos, sales_recap, sales_void, products, stock, purchasing, members, finance, users, roles, audit, settings, cost_prices.
Ide role tambahan yang sudah didiskusikan (belum dibuat): supervisor kasir, gudang, manajer cabang, auditor (read-only), marketing/member.

## 6. Aturan keamanan (WAJIB dipatuhi)
1. Hak akses **ditegakkan di database** (RLS + RPC). Guard di React (`RequirePerm`, `can()`) hanya untuk UX.
2. Browser hanya memakai **anon key**. `service_role` TIDAK BOLEH masuk frontend/repo. File rahasia: `.env`, `.env.import` (sudah di `.gitignore`, begitu juga `*.xlsx`, `*.csv`, `import-report/`). Jangan pernah meminta/menampilkan isinya.
3. Penjualan **hanya lewat RPC `create_sale`**: harga, diskon, cabang, stok dihitung ulang di server; klien cuma kirim `product_id`, `qty`, `discount_pct`. Tidak ada policy INSERT/UPDATE/DELETE langsung pada `sales`, `sale_items`, `stock`, `stock_movements`.
4. Transaksi **tidak dihapus**; koreksi lewat `void_sale` (alasan wajib, stok dikembalikan, tercatat di `audit_log`). Produk **tidak dihapus**, hanya `is_active=false`. Produk aktif wajib `price > 0` (constraint DB).
5. Stok tidak boleh minus; perubahan stok hanya lewat `adjust_stock` (barang masuk >0) dan `set_stock` (stok aktual/opname), keduanya mengecek hak `stock.u` **dan** akses cabang (`can_see_branch`); semua tercatat di `stock_movements` + `audit_log`.
6. Semua fungsi `security definer` memakai `set search_path = public`, mencabut `EXECUTE` dari `public/anon`, dan memberi ke `authenticated`.
7. Input pencarian dibersihkan (`shared/search.ts`) sebelum masuk filter PostgREST. Pesan login generik. Auto-logout idle 15 menit. Tanpa `dangerouslySetInnerHTML`.
8. Penulisan ke `roles`, `role_permissions`, `profiles`, `user_permissions` HANYA lewat RPC (`set_role_permission`, `set_user_permission`, `set_user_role`, `set_user_active`, `create_role`); tidak ada policy tulis langsung. Penjaga anti-eskalasi: tidak boleh mengubah hak/role/status diri sendiri; hak role `superadmin` dan akun superadmin tidak bisa diubah dari aplikasi; hanya superadmin yang boleh memberi role superadmin / `all_branches`; mencentang Tambah/Ubah/Hapus otomatis memberi Lihat. Pembuatan akun login hanya lewat Edge Function `create-user` (cek `has_perm('users','c')` atas nama pemanggil; menolak role superadmin; rollback bila profil gagal).
9. Semua akun baru WAJIB berformat `<username>@takom.id` (keputusan pemilik): dijaga di UI (NewUserModal hanya meminta username), Edge Function (`EMAIL_DOMAIN`, default takom.id) dan trigger DB (migrasi 006). Akun lama (superadmin@posweb.id) tidak diubah. Login menerima username saja (otomatis ditambah @takom.id).
10. Reset kata sandi: hanya superadmin (dicek di Edge Function `reset-password` langsung ke tabel profiles/roles, bukan dari klaim token), berlaku untuk semua role; kata sandi tidak pernah dicatat di audit_log; sesi lama user dikeluarkan lewat `revoke_user_sessions`. Pengguna mengganti kata sandinya sendiri di Pengaturan (min. 12 karakter).
11. Fungsi/perubahan SQL baru: buat sebagai migrasi bernomor berikutnya, **idempoten** (aman diulang), lalu tambahkan uji di `tests/sql-smoke.mjs`.

## 7. Data Excel sumber (`database28Ags.xlsx`, sheet `DataMaster`, baris 1 = judul, 32.656 produk, 37 kolom A–AK)
- A `produk id` = kode produk (TEKS, 10 karakter, ada yang alfanumerik seperti `1115AX0126`; unik) · B `prod Desc` = nama (maks 24 karakter; kolom F `Prod Nama Pnjng` = nama panjang) · O `Price2` = harga jual · AK `pengarang` (±55% kosong) · AG `Status` Y/N (N → nonaktif).
- N `Price1` = harga beli (rahasia). R `stokOnHand`, S `stokGudLain`, T `stokKonsinyasi`, U `stokPE`.
- Aturan impor (sudah diuji dry-run): harga 0 (1.984 produk) atau tidak valid (42, mis. `1,07E+11`) → diimpor **nonaktif**; 9 produk > Rp10 juta ditandai untuk dicek; 1 produk tanpa nama (`1115AX0126`). Hasil: 28.343 aktif / 4.313 nonaktif. Catatan lengkap di `import-report/products_perlu_dicek.csv` (dibuat skrip).
- Kolom lain disimpan di `products.attributes` sebagai array `[{"k": "<judul kolom>", "v": <nilai>}]` agar urutan Excel terjaga. Kolom harga beli → `product_costs.attributes`. Kolom stok tidak disimpan sebagai card.
- Impor: `npm run import:products -- file.xlsx --dry-run` lalu tanpa `--dry-run`. Default produk yang sudah ada DILEWATI (tidak menimpa harga yang diubah di aplikasi); `--update` menimpa. Stok awal: `--stock-branch=KODE` (hanya mengisi stok yang belum ada).

## 8. Cara menjalankan
1. Supabase SQL Editor (role `postgres`): jalankan `schema.sql` lalu `migrations/002` → `003` → `004` → `005` → `006` → `007` → `008` → `009` → `010` → `011` berurutan. Setelah 005, pasang Edge Function `create-user` dan `reset-password` (Supabase → Edge Functions → Deploy a new function → Via Editor, nama `create-user`, tempel isi `supabase/functions/create-user/index.ts`; biarkan Verify JWT aktif; opsional secret `ALLOWED_ORIGIN` = alamat web aplikasi). Fungsi ini BELUM diuji di Supabase.
2. Buat user di Authentication → Users (centang Auto Confirm), lalu isi `profiles` dengan SQL (lihat README). User tanpa baris `profiles` aktif akan langsung dikeluarkan oleh aplikasi.
3. `.env` dari `.env.example` (URL + anon key). `.env.import` dari `.env.import.example` (hanya untuk skrip impor, di komputer pemilik).
4. `npm install` → `npm run dev` (http://localhost:5173). Cek: `npx tsc --noEmit`, `npm run build`, `npm run test:sql`, `npm run test:e2e`, `npm run test:csv`, `npm run test:print`. Jalankan semua tes setiap mengubah SQL atau alur penjualan/stok; tambahkan kasus baru bila ada fitur baru.
Catatan lingkungan: shell sandbox kadang `sh` (tanpa brace expansion). Tailwind v4: jangan `@apply` kelas kustom; pakai `@utility`.

## 9. Status
**Selesai:** Pengguna & Hak Akses granular (migrasi 005 + halaman + Edge Function; SQL lolos tes lokal, UI/Edge Function belum diuji di Supabase), login, layout/tema, kasir (scan barcode, diskon per produk, bayar, struk), produk & harga (daftar, tambah/ubah, detail card, harga beli rahasia), stok per cabang (halaman Stok & Pengadaan, strip stok di kasir, detail produk), skrip impor, migrasi 002–004, tes SQL.
**Belum dibuat (urutan yang disarankan):**
1. (Pemilik) hitung fisik tiap cabang → impor lewat aplikasi → uji kasir dengan stok nyata. Fitur impor/mutasi/total sudah ada; sisanya pekerjaan data, bukan kode.
2. Rekap Penjualan: rekap harian kasir (cabangnya), rekap Kabag (inputan kasir), void transaksi (RPC `void_sale` sudah ada, UI belum).
3. Keuangan: rekap penjualan per metode bayar.
4. Halaman Cabang (tambah/nonaktifkan; saat ini cabang baru lewat SQL). Pengguna & Role SUDAH dibuat (lihat Status selesai) tetapi perlu diuji di Supabase sungguhan, termasuk Edge Function.
5. Purchase Order (fitur `purchasing` ada, tabel/halaman belum) dan halaman Member (tabel `members` ada; kasir saat ini hanya mengetik nomor/nama).
6. Hardening produksi: upgrade `react-router-dom` (npm audit moderat; JANGAN `npm audit fix --force`, itu memaksa lompat versi besar dan men-downgrade exceljs), header CSP/HSTS di hosting, MFA superadmin/keuangan, matikan sign-up publik di Supabase Auth, cadangan database.

## 10. Pertanyaan terbuka (tanya pemilik, jangan menebak)
- Konfirmasi pemilik untuk jalur stok awal di atas (hitung fisik per lokasi + impor per cabang). Cabang selain PUSAT harus ditambahkan dulu ke `branches` (butuh nama dan kode semua cabang).
- Barcode di buku berisi nomor apa? Pencarian scan kini mencocokkan **kode produk (kolom A)** persis. Jika barcode = ISBN (`prod ISBN` di Excel berformat `979-672-465-0`), perlu kolom/indeks pencarian ISBN.
- Konfirmasi ejaan cabang ke-6 (Antonius) dan nama orang untuk akun kasir tiap cabang. Daftar user Pusat menyusul.
- Printer struk (thermal 80mm via dialog cetak browser sudah ada; QZ Tray bila ingin cetak tanpa dialog).

## 11. Jangan lakukan
- Jangan mengubah keputusan di §4 atau melonggarkan §6.
- Jangan memakai kartu (card) untuk daftar produk; jangan menambah diskon custom.
- Jangan menaruh logika harga/diskon/stok di klien sebagai sumber kebenaran.
- Jangan membuat file tanpa aman-diulang untuk SQL; jangan menimpa data produk/stok yang sudah ada tanpa persetujuan pemilik.

## 12. Catatan serah-terima (22 Okt 2026)
Pemilik pindah ke agen lain karena kredit Claude gratis habis. Hal yang perlu ditanyakan ke pemilik di awal: (a) apakah migrasi `004_stock_views.sql` sudah dijalankan di Supabase; (b) apakah `delete from stock;` (membuang stok percobaan 100 pcs) sudah dijalankan; (c) angka yang muncul saat scan satu buku (kode produk atau ISBN); (d) nama + kode semua cabang. `npm run test:sql` butuh `npm install` dulu (paket `@electric-sql/pglite`).

## Format cetak (struk 80mm & nota A4)
- Dua format meniru nota lama TAKOM: **struk 80mm** (nota transaksi, otomatis tercetak setelah bayar) dan **nota A4** (laporan; tombol "Cetak nota A4" / "Cetak ulang struk" di banner setelah transaksi).
- Setiap elemen (kepala, label, judul kolom, kaki, tampil/sembunyi baris, kolom PPn, lebar, huruf) disimpan sebagai JSON di `print_templates` dan **hanya superadmin** yang bisa mengubah lewat halaman **Format Nota** (`/format-nota`, ada pratinjau langsung, "Cetak contoh", "Kembalikan bawaan"). Penulisan hanya lewat RPC `save_print_template` (cek superadmin di server, maks. 20 KB). Semua teks dirender sebagai teks React (tanpa HTML mentah).
- Token di teks: `{kasir} {cabang} {CABANG} {waktu} {tanggal} {no} {pelanggan}`. Pelanggan = member yang diketik kasir, bila kosong memakai `defaultCust`.
- Kolom PPn nota A4: hanya TAMPILAN (harga jual di sistem sudah termasuk pajak): harga tampil = harga / (1 + PPn efektif); bawaan PPn tertulis 12 dan efektif 11 (cocok dengan nota lama: 46.000 → 41.441). Total & stok tidak terpengaruh.
- Cetak ulang dari Rekap Penjualan sudah ada (struk 80mm & nota A4). Nomor nota memakai nomor sistem baru, bukan format `210726110001` lama.

## Rekap Penjualan (`/laporan`, fitur `sales_recap`)
- Alur: pilih **Bulan** → pilih **Tahun** (→ pilih **Cabang** bagi role lintas cabang; bawaan = cabang aktif, atau "Semua cabang") → kartu ringkasan (transaksi selesai, total penjualan, total diskon, void, total per metode bayar) + tabel transaksi **20 baris per halaman** (« ‹ Hal x dari y › »). Ganti bulan/tahun/cabang = kembali ke halaman 1.
- Batas bulan dihitung menurut **WIB** di SQL (`make_date(...)::timestamp at time zone 'Asia/Jakarta'`; JANGAN `timestamptz + interval '1 month'`, salah untuk Maret). Void tampil tapi tidak masuk total. Kasir/role satu cabang hanya melihat cabangnya (dipaksa server); cabang lain ditolak.
- Klik baris = detail transaksi (`sale_detail`): cetak struk 80mm / nota A4, dan **void** (butuh hak `sales_void.u`; alasan wajib; stok kembali). Void memanggil `void_sale` yang sudah ada.
- Belum: ekspor Excel/PDF rekap, rekap harian per kasir (tutup kasir), halaman Keuangan.
