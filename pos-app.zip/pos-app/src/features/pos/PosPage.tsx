import { useEffect, useRef, useState } from 'react'
import { keepPreviousData, useQuery, useQueryClient } from '@tanstack/react-query'
import { createSale, searchProducts } from './api'
import { PrintSheet } from '../print/views'
import { useInvoiceCfg, useReceiptCfg, type PrintData } from '../print/templates'
import { listBranches } from '../users/api'
import { StockByBranch } from '../stock/StockByBranch'
import { useAuth } from '../auth/AuthProvider'
import { rupiah } from '../../shared/format'
import { useDebounced } from '../../shared/hooks'
import type { CartLine, Method, Product, SaleResult } from './types'

const DISCOUNTS = [0, 5, 10, 15, 20, 25]
const dLabel = (d: number) => (d === 0 ? 'Tanpa diskon' : `${d}%`)
const METHODS: { key: Method; label: string }[] = [
  { key: 'cash', label: 'Tunai' }, { key: 'qris', label: 'QRIS' },
  { key: 'debit', label: 'Debit' }, { key: 'credit_card', label: 'Kartu Kredit' },
]
// items -> klik "Pembayaran" -> discount (diskon per produk / semua) -> payment (metode bayar)
type Step = 'items' | 'discount' | 'payment'
type Done = { sale: SaleResult; lines: CartLine[]; method: Method; cash: number; member: string; at: Date }

export default function PosPage() {
  const [step, setStep] = useState<Step>('items')
  const [q, setQ] = useState('')
  const dq = useDebounced(q, 200)
  const [cursor, setCursor] = useState(0)
  const [cart, setCart] = useState<CartLine[]>([])
  const [allDisc, setAllDisc] = useState<number | null>(null) // null = "diskon semua" mati
  const [member, setMember] = useState('')
  const [method, setMethod] = useState<Method | null>(null)
  const [cash, setCash] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [done, setDone] = useState<Done | null>(null)
  const qc = useQueryClient()
  const [printKind, setPrintKind] = useState<'receipt' | 'invoice'>('receipt')
  const receiptCfg = useReceiptCfg(), invoiceCfg = useInvoiceCfg() // dimuat sejak halaman dibuka agar siap saat cetak
  const { data: branches = [] } = useQuery({ queryKey: ['branches'], queryFn: listBranches })
  const { activeBranchId, allBranches, profile } = useAuth()
  const sellBranch = allBranches && activeBranchId && activeBranchId !== profile?.branch_id ? activeBranchId : undefined
  const searchRef = useRef<HTMLInputElement>(null)
  const scanning = useRef(false)

  const { data: products = [], isFetching } = useQuery({
    queryKey: ['products', dq], queryFn: () => searchProducts(dq), placeholderData: keepPreviousData,
  })

  const eff = (l: CartLine) => allDisc ?? l.disc
  const lineDisc = (l: CartLine) => Math.round((l.price * l.qty * eff(l)) / 100) // tampilan; server menghitung ulang
  const subtotal = cart.reduce((s, l) => s + l.price * l.qty, 0)
  const discAmt = cart.reduce((s, l) => s + lineDisc(l), 0)
  const total = subtotal - discAmt
  const anyDisc = cart.some((l) => eff(l) > 0)
  const memberOk = !anyDisc || member.trim().length > 0
  const cashNum = Number(cash.replace(/\D/g, '')) || 0

  // ganti cabang aktif = mulai transaksi baru (cegah keranjang terbawa ke cabang lain)
  useEffect(() => { setCart([]); setStep('items'); setAllDisc(null); setMember(''); setMethod(null); setCash('') }, [activeBranchId])
  useEffect(() => setCursor(0), [dq])
  useEffect(() => { if (step === 'items') searchRef.current?.focus() }, [step])
  useEffect(() => { document.querySelector(`[data-row="${cursor}"]`)?.scrollIntoView({ block: 'nearest' }) }, [cursor])
  useEffect(() => {
    if (!done) return
    setPrintKind('receipt') // struk 80mm otomatis; nota A4 lewat tombol
    const t = setTimeout(() => window.print(), 200)
    return () => clearTimeout(t)
  }, [done])

  function add(p: Product) {
    setCart((c) => {
      const i = c.findIndex((l) => l.id === p.id)
      if (i < 0) return [...c, { ...p, qty: 1, disc: 0 }]
      return c.map((l, j) => (j === i ? { ...l, qty: Math.min(l.qty + 1, 9999) } : l))
    })
  }
  const changeQty = (id: string, d: number) =>
    setCart((c) => c.map((l) => (l.id === id ? { ...l, qty: l.qty + d } : l)).filter((l) => l.qty > 0))
  const setLineDisc = (id: string, d: number) => setCart((c) => c.map((l) => (l.id === id ? { ...l, disc: d } : l)))

  /** Enter di langkah produk. Pemindai barcode mengetik kode lalu Enter dalam hitungan milidetik,
   *  sebelum daftar di layar sempat diperbarui, jadi kode dicari ulang saat itu juga. */
  async function onEnterItems() {
    const text = q.trim()
    if (text && (q !== dq || isFetching)) {
      if (scanning.current) return
      scanning.current = true
      try {
        const res = await searchProducts(text)
        const hit = res.find((p) => p.code === text) ?? (res.length === 1 ? res[0] : undefined)
        if (hit) { add(hit); setQ(''); setNotice('') }
        else setNotice(res.length === 0 ? `Produk "${text}" tidak ditemukan` : 'Ada beberapa hasil, pilih dengan ↑↓ lalu Enter')
      } catch { setNotice('Gagal mencari produk') } finally { scanning.current = false }
      return
    }
    const exact = text ? products.find((p) => p.code === text) : undefined
    const target = exact ?? products[cursor]
    if (target) { add(target); if (exact) setQ('') }
  }

  async function pay(m: Method) {
    if (busy || cart.length === 0) return
    setBusy(true); setError('')
    const lines = cart.map((l) => ({ ...l, disc: eff(l) }))
    try {
      const sale = await createSale(lines, member, m, m === 'cash' ? cashNum : undefined, sellBranch)
      setDone({ sale, lines, method: m, cash: cashNum, member: member.trim(), at: new Date() })
      void qc.invalidateQueries({ queryKey: ['stock-branches'] })
      setCart([]); setAllDisc(null); setMember(''); setMethod(null); setCash(''); setStep('items')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Transaksi gagal')
    } finally { setBusy(false) }
  }
  function printAgain(k: 'receipt' | 'invoice') { setPrintKind(k); setTimeout(() => window.print(), 200) }
  function printData(d: Done): PrintData {
    const bid = activeBranchId ?? profile?.branch_id
    return {
      invoiceNo: d.sale.invoice_no, at: d.at, cashier: profile?.full_name ?? '', branch: branches.find((b) => b.id === bid)?.name ?? profile?.branch_name ?? '',
      customer: d.member, lines: d.lines.map((l) => ({ code: l.code, name: l.name, price: l.price, qty: l.qty, disc: l.disc })),
      subtotal: d.sale.subtotal, discount: d.sale.discount, total: d.sale.total, method: d.method,
      paid: d.method === 'cash' ? d.cash : d.sale.total, change: d.sale.change,
    }
  }
  function choose(m: Method) {
    setMethod(m); setError('')
    if (m !== 'cash') void pay(m) // cashless: langsung cetak
  }

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const typing = (e.target as HTMLElement).tagName === 'INPUT'
      if (e.key === 'F2') { e.preventDefault(); setStep('items'); searchRef.current?.focus(); return }
      if (e.key === 'F8' && cart.length) {
        e.preventDefault()
        if (step === 'items') setStep('discount')
        else if (step === 'discount' && memberOk) setStep('payment')
        return
      }
      if (e.key === 'Escape') {
        if (step === 'items') { setQ(''); setNotice('') }
        else setStep(step === 'payment' ? 'discount' : 'items')
        return
      }
      if (step === 'items') {
        if (e.key === 'ArrowDown') { e.preventDefault(); setCursor((c) => Math.min(c + 1, products.length - 1)) }
        else if (e.key === 'ArrowUp') { e.preventDefault(); setCursor((c) => Math.max(c - 1, 0)) }
        else if (e.key === 'Enter') { e.preventDefault(); void onEnterItems() }
      } else if (step === 'payment' && !typing && !busy) {
        const m = METHODS[Number(e.key) - 1]
        if (m) choose(m.key)
      }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  })

  return (
    <>
      <div className="grid h-full grid-cols-[1fr_26rem] gap-4 p-4 print:hidden">
        {/* ---- kiri: daftar produk (baris, bukan kartu) ---- */}
        <section className="flex min-h-0 flex-col gap-3">
          {done && (
            <div className="rounded-2xl bg-success/20 px-4 py-2 text-success">
              {done.sale.invoice_no} tersimpan · Total {rupiah(done.sale.total)}
              {done.method === 'cash' && <b> · Kembalian {rupiah(done.sale.change)}</b>}
              <button className="btn-ghost ml-3 !py-1" onClick={() => printAgain('receipt')}>Cetak ulang struk</button>
              <button className="btn-ghost ml-2 !py-1" onClick={() => printAgain('invoice')}>Cetak nota A4</button>
            </div>
          )}
          <input ref={searchRef} className="input" placeholder="Scan barcode / cari kode atau nama produk (F2)" value={q}
            onChange={(e) => { setQ(e.target.value); setNotice('') }} maxLength={60} />
          {notice && <p role="status" className="px-2 text-sm text-warning">{notice}</p>}
          <div className="min-h-0 flex-1 overflow-auto rounded-2xl border border-border-muted">
            <table className="w-full text-left">
              <thead className="sticky top-0 bg-bg-dark">
                <tr><th className="w-40 px-4 py-2">Kode produk</th><th className="px-4 py-2">Nama produk</th><th className="w-40 px-4 py-2 text-right">Harga</th></tr>
              </thead>
              <tbody>
                {products.map((p, i) => (
                  <tr key={p.id} data-row={i} onClick={() => { setCursor(i); add(p) }}
                    className={`cursor-pointer border-t border-border-muted ${i === cursor ? 'bg-primary/20' : 'hover:bg-highlight/25'}`}>
                    <td className="px-4 py-2 font-mono">{p.code}</td>
                    <td className="px-4 py-2">{p.name}</td>
                    <td className="px-4 py-2 text-right">{rupiah(p.price)}</td>
                  </tr>
                ))}
                {products.length === 0 && <tr><td colSpan={3} className="px-4 py-6 text-center text-text-muted">Tidak ada produk</td></tr>}
              </tbody>
            </table>
          </div>
          {products[cursor] && (
            <div className="space-y-1 rounded-2xl bg-bg-light px-4 py-2 shadow-sm">
              <div className="truncate text-sm text-text-muted">Stok: {products[cursor].name}</div>
              <StockByBranch productId={products[cursor].id} />
            </div>
          )}
          <p className="text-sm text-text-muted">↑↓ pilih · Enter tambah · F8 pembayaran · Esc kembali</p>
        </section>

        {/* ---- kanan: keranjang + langkah ---- */}
        <aside className="flex min-h-0 flex-col gap-3 rounded-2xl bg-bg-light p-4 shadow">
          <div className="min-h-0 flex-1 space-y-3 overflow-auto">
            {cart.map((l) => (
              <div key={l.id} className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="min-w-0 flex-1"><div className="truncate">{l.name}</div><div className="text-sm text-text-muted">{rupiah(l.price)}</div></div>
                  <button className="btn-ghost !px-3 !py-0" onClick={() => changeQty(l.id, -1)} disabled={step === 'payment'}>−</button>
                  <span className="w-8 text-center">{l.qty}</span>
                  <button className="btn-ghost !px-3 !py-0" onClick={() => changeQty(l.id, 1)} disabled={step === 'payment'}>+</button>
                  <span className="w-24 text-right">{rupiah(l.price * l.qty)}</span>
                </div>
                {step === 'discount' && allDisc === null && (
                  <label className="flex items-center justify-end gap-2 text-sm">Diskon
                    <select className="input !w-auto !py-1" value={l.disc} onChange={(e) => setLineDisc(l.id, Number(e.target.value))}>
                      {DISCOUNTS.map((d) => <option key={d} value={d}>{dLabel(d)}</option>)}
                    </select>
                  </label>
                )}
                {step !== 'discount' && eff(l) > 0 && (
                  <div className="text-right text-sm text-primary">Diskon {eff(l)}% −{rupiah(lineDisc(l))}</div>
                )}
              </div>
            ))}
            {cart.length === 0 && <p className="text-text-muted">Keranjang kosong</p>}
          </div>

          <div className="space-y-1 border-t border-border-muted pt-3">
            <Line k="Subtotal" v={rupiah(subtotal)} />
            {discAmt > 0 && <Line k="Diskon" v={'-' + rupiah(discAmt)} />}
            <Line k="Total" v={rupiah(total)} big />
          </div>

          {step === 'items' && <button className="btn-primary" disabled={!cart.length} onClick={() => setStep('discount')}>Pembayaran (F8)</button>}

          {step === 'discount' && (
            <div className="space-y-3">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={allDisc !== null} onChange={(e) => setAllDisc(e.target.checked ? 0 : null)} />
                Diskon semua produk
              </label>
              {allDisc !== null && (
                <select className="input" value={allDisc} onChange={(e) => setAllDisc(Number(e.target.value))} aria-label="Diskon semua produk">
                  {DISCOUNTS.map((d) => <option key={d} value={d}>{dLabel(d)}</option>)}
                </select>
              )}
              {anyDisc && (
                <input className="input" autoFocus placeholder="Member / nomer member" value={member} maxLength={40}
                  onChange={(e) => setMember(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && memberOk) setStep('payment') }} />
              )}
              <button className="btn-primary w-full" disabled={!memberOk} onClick={() => setStep('payment')}>Lanjut ke metode bayar (F8)</button>
            </div>
          )}

          {step === 'payment' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {METHODS.map((m, i) => (
                  <button key={m.key} disabled={busy} className={method === m.key ? 'btn-primary' : 'btn-ghost'} onClick={() => choose(m.key)}>
                    {i + 1}. {m.label}
                  </button>
                ))}
              </div>
              {method === 'cash' && (
                <div className="space-y-2">
                  <input className="input" autoFocus inputMode="numeric" placeholder="Uang diterima" value={cash}
                    onChange={(e) => setCash(e.target.value.replace(/\D/g, ''))}
                    onKeyDown={(e) => { if (e.key === 'Enter' && cashNum >= total) void pay('cash') }} />
                  <button className="btn-ghost w-full" onClick={() => setCash(String(total))}>Uang pas</button>
                  <Line k="Kembalian" v={cashNum >= total ? rupiah(cashNum - total) : '—'} big />
                  <button className="btn-primary w-full" disabled={busy || cashNum < total} onClick={() => pay('cash')}>
                    {busy ? 'Memproses…' : 'Bayar & cetak'}
                  </button>
                </div>
              )}
            </div>
          )}
          {error && <p role="alert" className="text-sm text-danger">{error}</p>}
        </aside>
      </div>
      {done && <PrintSheet kind={printKind} data={printData(done)} receipt={receiptCfg} invoice={invoiceCfg} />}
    </>
  )
}

const Line = ({ k, v, big }: { k: string; v: string; big?: boolean }) => (
  <div className={`flex justify-between ${big ? 'text-xl font-semibold' : ''}`}><span>{k}</span><span>{v}</span></div>
)
